#Dati h,m,s espressi con n interi restituisce una stringa con l'ora in UTC
def oraUTC(h,m,s):
	if(s>10):
		s=str(s)
	else:
		s='0'+str(s)

	if(m>=10 and h>=10):
		datas='T'+str(h)+':'+str(m)+':'+s+'Z'
	else:
		if(m<10 and h<10):
			datas='T0'+str(h)+':0'+str(m)+':'+s+'Z'
		else:
			if(m<10):
				datas='T'+str(h)+':0'+str(m)+':'+s+'Z'
			else:
				datas='T0'+str(h)+':'+str(m)+':'+s+'Z'
	return datas
#Dati anno,mese,giorno espressi con n interi restituisce una stringa con la data in UTC
def dataUTC(anno,mese,giorno):
	if(int(giorno)<10):
		giorno='0'+str(giorno)
	if(int(mese)<10):
			mese='0'+str(mese)
	if(int(anno)<10):
		anno='200'+str(anno)
	else:
		if(int(anno)>=90):
			anno='19'+str(anno)
		else:
			anno='20'+str(anno)
	datag=str(anno)+"-"+str(mese)+"-"+str(giorno)
	return datag
#Dato un anno con le ultime due cifre aggiunge le prime due
def aggAnno(anno):
	if(int(anno)<10):
		anno='200'+str(anno)
	else:
		if(int(anno)>=90):
			anno='19'+str(anno)
		else:
			anno='20'+str(anno)
	return (int(anno))

#Converte il wind in GDR
def convertWind(wind):
	ris=0
	if(wind=="E"):
		ris=90
	elif(wind=="ENE"):
		ris=67.5
	elif(wind=="ESE"):
		ris=112.5
	elif(wind=="N"):
		ris=0
	elif(wind=="NE"):
		ris=45
	elif(wind=="NNE"):
		ris=22.5
	elif(wind=="NNW"):
		ris=337.5
	elif(wind=="NW"):
		ris=315
	elif(wind=="S"):
		ris=180
	elif(wind=="SE"):
		ris=135
	elif(wind=="SSE"):
		ris=157.5
	elif(wind=="SSW"):
		ris=202.5
	elif(wind=="SW"):
		ris=225
	elif(wind=="W"):
		ris=270
	elif(wind=="WNW"):
		ris=292.5
	elif(wind=="WSW"):
		ris=247.5
	else:
		ris=-1
	return ris
#esegue una somma e sottrazione
def somma(a,b):
    return(a+b,a-b)
