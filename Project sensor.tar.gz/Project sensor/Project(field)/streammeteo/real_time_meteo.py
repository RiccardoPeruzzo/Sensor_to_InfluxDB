#imposto tagname
measurement="meteorology"
sensor="GEO7MPTE"
location="XXX"


#Dato un file di testo ottiene i parametri da passare a influx perche gli registri come dati
#Nome file
import requests
import datetime
import time
import filecmp
import os.path
import subprocess  
import shutil
#wget --timeout=10 -t 3 -r -N -nd http://192.168.253.4/B/clientraw.txt
subprocess.call(["wget","--timeout=10","-t"," 3", "-r", "-N", "-nd", "http://192.168.253.4/B/clientraw.txt"])
print('pronto il nuovo file') 
if(os.path.exists('Ultimi_dati_inseriti.txt')!=True):
	g = open('Ultimi_dati_inseriti.txt', 'w')
	g.close()
print(filecmp.cmp('clientraw.txt', 'Ultimi_dati_inseriti.txt'))
if((filecmp.cmp('clientraw.txt', 'Ultimi_dati_inseriti.txt'))!=True):
	print("scrivo su database")
	shutil.copy('clientraw.txt', 'Ultimi_dati_inseriti.txt')

	f = open('clientraw.txt', 'r')
	g = open('datiPerInfluxreal.txt', 'w')
	conta=0
	j=0
	contatempo=0
	#flag per la stringa
	pronto=0
	#Numero campi
	ncamp=48
	#N campi con una sola parola nel campo
	ncamps=48
	#con due parole e cosi via
	ncampd=0
	ncampt=0
	cont=range(ncamp)
	campo=[]
	#questo va modificato nel caso ci siano campi con piu parole
	nCampSpace=ncamps+(ncampd*2)+(ncampt*3)
	#inizializzo campi
	for i in range(ncamp-1):
		campo[i:i]='iniz'

	#Nome campi, prima di un carattere spazio,virgola e uguale va usato il backslash'\' per l'escaping
	campo[0]='ID\ code'
	campo[1]='Average\ windspeed\ (kts)'
	campo[2]='Gust'
	campo[3]='Wind\ direction'
	campo[4]='Temperature\ (oC)'
	campo[5]='Outdoor\ humidity\ (%)'
	campo[6]='Barometer\ (hpa)'
	campo[7]='Daily\ rainfall\ (mm)'
	campo[8]='Monthly\ rainfall\ (mm)'
	campo[9]='Yearly\ rainfall\ (mm)'
	campo[10]='Rain\ rate\ (mm/min)'
	campo[11]='Max\ rain\ rate\ (mm/min)\ for\ the\ day'
	campo[12]='Indoor\ temperature\ (oC)'
	campo[13]='Indoor\ humidity\ (%)'
	campo[14]='Soil\ temperature\ (oC)'
	campo[15]='Forecast\ icon'
	campo[16]='WMR968\ extra\ temperature\ (oC)'
	campo[17]='WMR968\ extra\ humidity\ (%)'
	campo[18]='WMR968\ extra\ sensor\ number'
	campo[19]='Yesterday\ rainfall\ (mm)'
	campo[20]='Extra\ temperature\ sensor\ #1\ (oC)'
	campo[21]='Extra\ temperature\ sensor\ #2\ (oC)'
	campo[22]='Extra\ temperature\ sensor\ #3\ (oC)'
	campo[23]='Extra\ temperature\ sensor\ #4\ (oC)'
	campo[24]='Extra\ temperature\ sensor\ #5\ (oC)'
	campo[25]='Extra\ temperature\ sensor\ #6\ (oC)'
	campo[26]='Extra\ humidity\ sensor\ #1\ (%)'
	campo[27]='Extra\ humidity\ sensor\ #2\ (%)'
	campo[28]='Extra\ humidity\ sensor\ #3\ (%)'
	campo[29]='Hour'
	campo[30]='Minute'
	campo[31]='Seconds'
	campo[32]='Stationname'
	campo[33]='Lightning\ counts\ since\ noon'
	campo[34]='Actual\ solar\ reading'
	campo[35]='Day'
	campo[36]='Month'
	campo[37]='WMR968\ battery\ level\ 1'
	campo[38]='WMR968\ battery\ level\ 2'
	campo[39]='WMR968\ battery\ level\ 3'
	campo[40]='WMR968\ battery\ level\ 4'
	campo[41]='WMR968\ battery\ level\ 5'
	campo[42]='WMR968\ battery\ level\ 6'
	campo[43]='WMR968\ battery\ level\ 7'
	campo[44]='Current\ windchill\ reading\ (oC)'
	campo[45]='Current\ humidex\ value\ (oC)'
	campo[46]='Maximum\ daily\ temperature\ (oC)'
	campo[47]='Minimum\ daily\ temperatuer\ (oC)'
      
	point=""
	datao=""
	#creo un file di testo adatto per essere inviato a influxdb
	for line in f:
		words = line.split()
		for word in words:
			#Primo campo, in realta il primo campo e Time e andro a inserirlo dopo
			if(j==0):
				point=','+campo[j]+'='+word
				j=j+1
			else:
				if(j==(ncamp-1)):
					point=point+','+campo[j]+'='+word+'\n'
					j=j+1
			#Altri campi
				else:
					#gestisco campo stringa
					#campo data
					if(j==32):
						#diviso in due parti stazione e ora
						parti = word.split("-")
						flagparte=0
						for parte in parti:
						#parte stazione
							if (flagparte==0):
								point=point+','+campo[j]+'='+'"'+parte+'"'
								flagparte=1
							#parte data
							else:
								datao=parte
						j=j+1
					else:
						#campo data
						if(j==74):
							datag=word
							#Adesso ho data e ora li devo inserire nel campo Time
							#datag=06/21/2016 datao="14:27:18"
							#Sistemo datag
							giorno=0
							mese=0
							anno=0
							listadata=datag.split('/')
							for pezzodata in listadata:
								if(mese==0):
									mese=pezzodata
								else:
									if(giorno==0):
										giorno=pezzodata
									else:
										anno=pezzodata	
							datag=str(anno)+"-"+str(mese)+"-"+str(giorno)+"T"
							#Sistemo datao	
							datao=datao+"Z"
							#li metto assieme
							data='"'+datag+datao+'"'
							point=measurement+',sensor='+sensor+',location='+location+" Time="+data+point
							#scrivo point su un file
							g.write(point)
							j=j+1
						else:
							if(j<ncamp):
								point=point+','+campo[j]+'='+word
							j=j+1
	g.close()
	r = requests.post('http://localhost:8086/write?db=meteornorm',
    	data=file('datiPerInfluxreal.txt','rb').read())
	#curl -XPOST 'http://localhost:8086/write?db=meteornorm' --data-binary @datiPerInfluxreal.txt
	print("programma eseguito correttamente")
	g.close()
else:
	print("file gia presente")

