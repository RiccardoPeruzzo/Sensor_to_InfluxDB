#imposto tagname
measurement="currents_sea_level_and_waves"
sensor="GEO7MPTE"
location="XXX"

#Dato un file di testo ottiene i parametri da passare a influx perche gli registri come dati
#Nome file
import auxwap
import requests
import datetime
import time
import filecmp
import os.path
import subprocess  
import shutil
#wget --timeout=10 -t 3 -r -N -nd http://192.168.253.4/B/clientraw.txt
#ipotizzando di avere 17 rilevazioni
#IP=...
k=0
while(k<16):
	if(k==0):
		nomefile="export.wap"
		tagname="wapsensor"
	else:
		#devo aggiungere lo zero
		if(k<10):
			nomefile="export.c"+"0"+str(k)
		else:
			nomefile="export.c"+str(k)
		tagname="Quota_"+str(k-16)
	filecontrollo='Ultimi_dati_inseriti_'+nomefile
	print("elaboro"+tagname)	
	k=k+1
	#Scarico il rilevamento e controllo che non fosse gia presente
	#Da togliere il commento in caso real time
	#subprocess.call(["wget","--timeout=10","-t"," 3", "-r", "-N", "-nd", "http://"+IP+"/B/"+nomefile])
	print('pronto il nuovo file') 
	if(os.path.exists(filecontrollo)!=True):
		g = open(filecontrollo, 'w')
		g.close()
	print(filecmp.cmp(nomefile, filecontrollo))
	if((filecmp.cmp(nomefile, filecontrollo))!=True):
		print("scrivo su database")
		shutil.copy(nomefile, filecontrollo)

		#se e single.wap
		if(k==1):
			f = open(nomefile, 'r')
			g = open('datiPerInfluxreal.txt', 'w')
			j=0
			#Numero campi
			ncamp=22
			campo=[]
	
			#inizializzo campi
			for i in range(ncamp-1):
				campo[i:i]='iniz'

			#Nome campi, prima di un carattere spazio,virgola e uguale va usato il backslash'\' per l'escaping
			#Spect Type se questo campo e zero non va salvato
			campo[0]='Hm0'
			campo[1]='H3'
			campo[2]='H10'
			campo[3]='Hmax'
			campo[4]='Hmean'
			campo[5]='Tm02'
			campo[6]='TP'
			campo[7]='Tz'
			campo[8]='T3'
			campo[9]='T10'
			campo[10]='Tmax'
			campo[11]='Dir_Tp'
			campo[12]='Spr_Tp'
			campo[13]='Mean_dir'
			campo[14]='UI'
			campo[15]='Mean_Press'
			campo[16]='Mean_AST dist'
			campo[17]='#bad_detects'
			campo[18]='curr_speed'
			campo[19]='curr_dir'
			campo[20]='error_code'
#rilevazione,identifier=wapsensor Time="2015-10-23T08:31:01Z",Average\ windspeed\ (kts)=0.57,Hm0=0.54,H3=0.66,H10=0.82,Hmax=0.00,Hmean=2.76,Tm02=3.73,TP=2.79,Tz=0.00,T3=0.00,T10=0.00,Tmax=67.28,Dir\ Tp=36.49,Spr\ Tp=72.28,Mean\ dir=16.180,UI=16.652,Mean\ Press=6,Mean\ AST\ dist=0.06,#bad\ detects=220.3,curr\ speed="No Errors"
			#mi sposto tra i campi che mi interessano
			i=0
			point=""
			conta=0
			
			point=measurement+",sensor="+sensor+',location='+location+",proof="+tagname
			#creo un file di testo adatto per essere inviato a influxdb
			for line in f:
				
					
				words = line.split()
				for word in words:
					#print word
					#Mese
					if(j==0):
						mese=str(word)
						j=j+1
					#anno
					elif(j==1):
						giorno=str(word)
						j=j+1
					#giorno
					elif(j==2):
						anno=str(word)
						j=j+1	
					#Ore
					elif(j==3):
						ore=str(word)
						j=j+1	
					#Minuti
					elif(j==4):
						minuti=str(word)
						j=j+1
					#Secondi
					elif(j==5):
						secondi=str(word)
						j=j+1
					#Spectype se 0 non scrivo la rilevazione
					elif(j==6):
						if(int(word)==0):
							j=-1
						#2015-06-11T20:46:02Z
						else:
							data=anno+"-"+mese+"-"+giorno+"T"+ore+":"+minuti+":"+secondi+"Z"
							j=j+1
							punto=""
							#Aggiungo timestamp
							dt=datetime.datetime(int(anno),int(mese),int(giorno),int(ore),int(minuti),int(secondi))
							dt=((dt-datetime.datetime(1970,1,1)).total_seconds())
							dt=int(dt)
					#Caso in cui il dato sia da buttare per Spectype==0
					elif(j==-1):
						j=-1
					#campi da aggiungere escluso l'ultimo
					elif(j==7 or j==8 or j==9 or j==10 or j==11 or j==12 or j==13 or j==14 or j==15 or j==16 or j==17 or j==18 or j==19 or j==20 or j==21 or j==22 or j==23 or j==26 or j==28 or j==29):
						punto=punto+point+",observed_property="+campo[i]+',error={error}'+' value='+word+' '+str(dt)+'000000000'+'\n'
						i=i+1
						j=j+1			
					#campo errori
					elif(j==30):
						err=word
						word=auxwap.sostituisciErrori(auxwap.calcolareErrori(int(word)))
						punto=punto+point+",observed_property="+campo[i]+',error={error}'+' info_error="'+word+'" '+str(dt)+'000000000'+'\n'
						if (int(err)==0):
							punto=punto.format(error=0)
						else:
							punto=punto.format(error=1)
						g.write(punto)
						j=0
						i=0
					#ultimo campo da aggiungere nel caso non sia error
					#elif(j==ncamp-1):
					#	point=point+","+campo[i]+"="+word+"\n"
						#scrivo point su un file
					#	g.write(point)
					#	j=j+1
					#campi da saltare
					else:
						j=j+1						
			g.close()

		#Se e singlecXX
		else:
			f = open(nomefile, 'r')
			g = open('datiPerInfluxreal.txt', 'w')
			j=0
			#Numero campi
			ncamp=2
			campo=[]
	
			#inizializzo campi
			for i in range(ncamp-1):
				campo[i:i]='iniz'

			#Nome campi, prima di un carattere spazio,virgola e uguale va usato il backslash'\' per l'escaping
			#Spect Type se questo campo e zero non va salvato
			campo[0]='Dir'
			campo[1]='V'
	
			#mi sposto tra i campi che mi interessano
			i=0
			point=measurement+",sensor="+sensor+',location='+location+",proof="+tagname
			punto=""
			#creo un file di testo adatto per essere inviato a influxdb
			for line in f:
				words = line.split()
				for word in words:
					#Mese
					if(j==0):
						mese=str(word)
						j=j+1
					#anno
					elif(j==1):
						giorno=str(word)
						j=j+1
					#giorno
					elif(j==2):
						anno=str(word)
						j=j+1	
					#Ore
					elif(j==3):
						ore=str(word)
						j=j+1	
					#Minuti
					elif(j==4):
						minuti=str(word)
						j=j+1
					#Secondi
					elif(j==5):
						secondi=str(word)
						data=anno+"-"+mese+"-"+giorno+"T"+ore+":"+minuti+":"+secondi+"Z"
						#Aggiungo timestamp
						dt=datetime.datetime(int(anno),int(mese),int(giorno),int(ore),int(minuti),int(secondi))
						dt=((dt-datetime.datetime(1970,1,1)).total_seconds())
						dt=int(dt)
						punto=""
						j=j+1
						
					#campi da aggiungere escluso l'ultimo
					elif(j==10):
						punto=punto+point+",observed_property="+campo[i]+' value='+word+' '+str(dt)+'000000000'+'\n'
						i=i+1
						j=j+1			
					#ultimo campo da aggiungere
					elif(j==11):
						
						punto=punto+point+",observed_property="+campo[i]+' value='+word+' '+str(dt)+'000000000'+'\n'
						j=j+1
						#scrivo point su un file
						g.write(punto)
					elif(j==14):
						j=0
						i=0
					#campi da saltare
					else:
						j=j+1						
			g.close()

		r = requests.post('http://localhost:8086/write?db=waptag',
	    	data=file('datiPerInfluxreal.txt','rb').read())
		#curl -XPOST 'http://localhost:8086/write?db=waptag' --data-binary @datiPerInfluxreal.txt
		print("programma eseguito correttamente")
		g.close()
	else:
		print("file gia presente")

