#Data la somma di errori espressa in binario la divide
def calcolareErrori(cod):
	cod=int(cod)
	#la flag diventa 1 quando trovotutti i numeri
	flag=0
	pot=2
	ris=""
	if (cod!=0):
		while(pot<=cod):
			pot=pot*2
		pot=pot/2
		while(cod!=0):
			if((cod-pot)>=0):
				cod=cod-pot
				if(cod==0):
					ris=ris+str(pot)
				else:
					ris=ris+str(pot)+","
					pot=pot/2
			else:
				pot=pot/2
	else:
		ris=str(0)
	return ris
#Prende una stringa di errori e li sostituisce con la loro descrizione
def sostituisciErrori(lista):
	primo=0
	words=lista.split(",")
	for word in words:
		#in base all'errore viene restituito un messaggio diverso
		if(int(word)==0):
			errore="No Errors"
		if(int(word)==1):
			errore="No Pressure"
		if(int(word)==2):
			errore="Low Pressure"
		if(int(word)==4):
			errore="Low Amplitude"
		if(int(word)==8):
			errore="White Noise Test"
		if(int(word)==16):
			errore="Unreasonable Estimate"
		if(int(word)==32):
			errore="Never Processed"
		if(int(word)==64):
			errore="AST Out of Bounds"
		if(int(word)==128):
			errore="Directional Ambiguity"
		if(int(word)==256):
			errore="No Pressure Peak"
		if(int(word)==512):
			errore="Close to clipping"
		if(int(word)==1024):
			errore="High AST Data Loss"
		if(int(word)==2048):
			errore="Excessive tilt"
		if(primo==0):
			ris=errore
			primo=1
		else:	
			ris=ris+","+errore
	return ris
