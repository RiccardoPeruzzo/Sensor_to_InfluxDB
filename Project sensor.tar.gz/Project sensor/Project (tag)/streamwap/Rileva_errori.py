import auxwap
cod="143"
lista=auxwap.calcolareErrori(cod)
print(auxwap.sostituisciErrori(lista))
