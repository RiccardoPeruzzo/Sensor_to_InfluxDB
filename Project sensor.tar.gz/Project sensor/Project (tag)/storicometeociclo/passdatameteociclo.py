#imposto tagname
measurement="meteorology"
sensor="GEO7MPTE"
location="XXX"



import auxstoricometeociclo
import requests
import datetime
import time
import os.path
nfile=1
filename='meteoptf'+str(nfile)+'.txt'
while(os.path.exists(filename)==True):
	#open
	print("elaborato file"+str(nfile))
	nfile=nfile+1

	#Dato un file di testo ottiene i parametri da passare a influx perche gli registri come dati
	#Nome file

	f = open(filename, 'r')
	filename='meteoptf'+str(nfile)+'.txt'
	g = open('datiPerInflux.txt', 'w')
	conta=0
	j=0
	contatempo=0
	#flag per la stringa
	pronto=0
	#Numero campi
	ncamp=28
	#N campi con una sola parola nel campo
	ncamps=4
	#con due parole e cosi via
	ncampd=25
	ncampt=1
	cont=range(ncamp)
	campo=[]
	#questo va modificato nel caso ci siano campi con piu parole
	nCampSpace=ncamps+(ncampd*2)+(ncampt*3)
	#inizializzo campi
	for i in range(ncamp-1):
		campo[i:i]='iniz'

	#Nome campi, prima di un carattere spazio,virgola e uguale va usato il backslash'\' per l'escaping
	#il campo zero va lasciato vuoto, non verra visualizzato

	campo[0]='Temp\ Out'
	campo[1]='Hi\ Temp'
	campo[2]='Low\ Temp'
	campo[3]='Out\ Hum'
	campo[4]='Dew\ Pt.'
	campo[5]='Wind\ Speed'
	campo[6]='Wind\ Dir'
	campo[7]='Wind\ Run'
	campo[8]='Hi\ Speed'
	campo[9]='Hi\ Dir'
	campo[10]='Wind\ Chill'
	campo[11]='Heat\ Index'
	campo[12]='THW\ Index'
	campo[13]='Bar'
	campo[14]='Rain'
	campo[15]='Rain\ Rate'
	campo[16]='Heat\ D-D'
	campo[17]='Cool\ D-D'
	campo[18]='In\ Temp'
	campo[19]='In\ Hum'
	campo[20]='In\ Dew'
	campo[21]='In\ Heat'
	campo[22]='In\ EMC'
	campo[23]='In\ Air\ Density'
	campo[24]='Wind\ Samp'
	campo[25]='Wind\ Tx'
	campo[26]='ISS\ Recept'
	campo[27]='Arc.\ Int.'

	s=0
	i=0
	
	#creo un file di testo adatto per essere inviato a influxdb
	for line in f:
		words = line.split()
		for word in words:
			#zona variabili
		
			if(conta<(nCampSpace)):
				conta=conta+1
				#print(word)
		
			else:	
				#Primo campo
				if(j==0):
					punto=""
					point=measurement+',sensor='+sensor+',location='+location
					#5/1/16 to 2015-06-11
					#Data una stringa carattere per carattere
					giorno=0
					mese=0
					anno=0
					listadata=word.split('/')
					for pezzodata in listadata:
						if(giorno==0):
							giorno=pezzodata
							#print pezzodata
						else:
							if(mese==0):
								mese=pezzodata
							else:
								anno=pezzodata	
					anno=int(anno)	
					mese=int(mese)	
					giorno=int(giorno)		
					datag=auxstoricometeociclo.dataUTC(anno,mese,giorno)
					anno=auxstoricometeociclo.aggAnno(anno)	
					j=j+1
				elif(j==1):
					m=float(word)%1
					h=float(word)-m
					h=int(h)
					m=m*100
					m=int(m)
					s=0
					datas=auxstoricometeociclo.oraUTC(h,m,s)
					#Timestamp
					dt=datetime.datetime(anno,mese,giorno,h,m)
					dt=((dt-datetime.datetime(1970,1,1)).total_seconds())
					dt=int(dt)
					j=j+1
				#Campo wind da convertire
				elif(j==8 or j==11):
					word=auxstoricometeociclo.convertWind(word)
					if(word!=-1):
						punto=punto+point+",observed_property="+campo[i]+' value='+str(word)+' '+str(dt)+'000000000'+'\n'
					j=j+1
					i=i+1	
				#Ultimo campo 
				elif(j==29):
					punto=punto+point+",observed_property="+campo[i]+' value='+word+' '+str(dt)+'000000000'+'\n'
					#scrivo point su un file
					i=0
					j=0
					#print (point)
					g.write(punto)
				#Altri campi
				else:
					if(word!='#N/D'):
						punto=punto+point+",observed_property="+campo[i]+' value='+word+' '+str(dt)+'000000000'+'\n'
					j=j+1
					i=i+1
	g.close()
	r = requests.post('http://localhost:8086/write?db=meteoctag',
	    data=file('datiPerInflux.txt','rb').read())
	#curl -XPOST 'http://localhost:8086/write?db=meteoctag' --data-binary @datiPerInflux.txt
	print("programma eseguito correttamente")
	g.close()
print("fine elaborazione, sono stati eleborati "+str(nfile-1)+" file")
#2015-06-11T20:46:02Z	
#1465902787393628873
#1468672891










	
